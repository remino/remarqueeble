var e=`direction`,t=`behavior`,n=`scrollamount`,r=`scrolldelay`,i=`truespeed`,a=`loop`,o=`bgcolor`,s=`width`,c=`height`,l=`hspace`,u=`vspace`,d=`--attr-width`,f=`--attr-height`,p=`--attr-hspace`,m=`--attr-vspace`,h=`--attr-bgcolor`,g=`--animation-duration`,_=`--animation-direction`,v=`--animation-iteration-count`,y=`--animation-play-state`,b=`--animation-timing-function`,x=`--translate-x-end`,S=`--translate-x-start`,C=`--translate-y-end`,w=`--translate-y-start`,T=globalThis.HTMLElement??class{},E=e=>{if(e===null)return null;let t=e.trim();return t===``?null:/^[+-]?(?:\d+|\d*\.\d+)$/.test(t)?`${t}px`:globalThis.CSS?.supports(`width`,t)?t:null},D=[{attribute:s,cssVar:d,parser:E},{attribute:c,cssVar:f,parser:E,fallback(e){return e.isVerticalDirection&&!e.hasAttribute(c)?`200px`:null}},{attribute:l,cssVar:p,parser:E},{attribute:u,cssVar:m,parser:E},{attribute:o,cssVar:h,parser:e=>{if(e===null)return null;let t=e.trim();return t===``?null:globalThis.CSS?.supports(`background-color`,t)?t:null}}],O=class extends T{static observedAttributes=[e,t,n,r,i,a,o,s,c,l,u];track;running=!1;constructor(){super();let e=this.attachShadow({mode:`open`});e.innerHTML=`
			<style>
				:host {
					display: inline-block;
					text-align: initial;
					overflow: hidden !important;
					white-space: nowrap;
					width: var(${d}, calc(100% - (var(--attr-hspace, 0px) * 2)));
					height: var(${f}, auto);
					margin-inline: var(${p}, 0px);
					margin-block: var(${m}, 0px);
					background-color: var(${h}, transparent);
					box-sizing: border-box;
				}

				:host([direction="up"]),
				:host([direction="down"]) {
					white-space: normal;
				}

				.track {
					animation: remarqueeble-motion
						var(${g}, 10s)
						var(${b}, linear)
						var(${v}, infinite)
						var(${_}, normal)
						both;
					animation-play-state: var(${y}, running);
					display: inline-block;
					will-change: transform;
				}

				@keyframes remarqueeble-motion {
					from {
						transform: translate(
							var(${S}, 100%),
							var(${w}, 0px)
						);
					}

					to {
						transform: translate(
							var(${x}, -100%),
							var(${C}, 0px)
						);
					}
				}
			</style>

			<span class="track"><slot></slot></span>
		`;let t=e.querySelector(`.track`);if(!t)throw Error(`Remarqueeble track element was not created.`);this.track=t,this.track.addEventListener(`animationend`,()=>this.handleAnimationEnd())}connectedCallback(){this.running=!0,this.syncPresentationalHints(),requestAnimationFrame(()=>{!this.isConnected||!this.running||this.reset()})}disconnectedCallback(){this.running=!1}attributeChangedCallback(e,t,n){t!==n&&(this.syncPresentationalHints(),this.isConnected&&this.reset())}get direction(){return this.getAttribute(e)||`left`}get behavior(){return this.getAttribute(t)||`scroll`}get scrollAmount(){let e=this.getAttribute(n),t=e===null||e.trim()===``?NaN:Number(e);return Number.isFinite(t)&&t>=0?t:6}get scrollDelay(){let e=this.getAttribute(r),t=e===null||e.trim()===``?NaN:Number(e),n=Number.isFinite(t)&&t>=0?t:85;return this.hasAttribute(i)?n:Math.max(n,60)}get loop(){let e=this.getAttribute(a);return e===null?-1:Number(e)}get directionSign(){return this.direction===`right`||this.direction===`down`?1:-1}get isVerticalDirection(){return this.direction===`up`||this.direction===`down`}start(){this.running||(this.running=!0,this.reset(),this.syncAnimationPlayState())}stop(){this.running=!1,this.syncAnimationPlayState()}syncPresentationalHints(){for(let e of D)this.syncVar(e);this.syncAnimationPlayState()}syncVar(e){let t=this.getAttribute(e.attribute),n=e.parser(t),r=e.fallback?e.fallback(this):null;if(n==null){r==null?this.style.removeProperty(e.cssVar):this.style.setProperty(e.cssVar,r);return}this.style.setProperty(e.cssVar,n)}reset(){let e=this.getHostSize(),t=this.getTrackSize();this.syncAnimation(e,t)}getHostSize(){return this.isVerticalDirection?this.clientHeight:this.clientWidth}getTrackSize(){return this.isVerticalDirection?this.track.offsetHeight:this.track.offsetWidth}getStartPosition(e,t){return this.directionSign<0?e:-t}getFlushEndPosition(e,t){return this.directionSign<0?0:e-t}getOffEndPosition(e,t){return this.directionSign<0?-t:e}getSlideEndPosition(e,t){return this.directionSign<0?0:e-t}getAlternateStartPosition(e,t){return this.directionSign<0?e-t:0}syncAnimationPlayState(){this.style.setProperty(y,this.running?`running`:`paused`)}syncAnimation(e,t){let n=this.behavior===`alternate`?this.getAlternateStartPosition(e,t):this.getStartPosition(e,t),r=this.behavior===`slide`?this.getSlideEndPosition(e,t):this.behavior===`alternate`?this.getFlushEndPosition(e,t):this.getOffEndPosition(e,t),i=Math.abs(r-n),a=Math.max(1,Math.ceil(i/Math.max(1,this.scrollAmount))),o=Math.max(1,a*this.scrollDelay),s=this.getCssIterationCount();this.track.style.removeProperty(`transform`),this.style.setProperty(g,`${o}ms`),this.style.setProperty(_,this.behavior===`alternate`?`alternate`:`normal`),this.style.setProperty(v,s),this.style.setProperty(b,`steps(${a}, end)`),this.isVerticalDirection?(this.style.setProperty(S,`0px`),this.style.setProperty(x,`0px`),this.style.setProperty(w,`${n}px`),this.style.setProperty(C,`${r}px`)):(this.style.setProperty(S,`${n}px`),this.style.setProperty(x,`${r}px`),this.style.setProperty(w,`0px`),this.style.setProperty(C,`0px`)),this.restartAnimation()}getCssIterationCount(){return this.behavior===`slide`&&!this.hasAttribute(a)?`1`:this.hasAttribute(a)&&Number.isFinite(this.loop)&&this.loop>0?String(this.loop):`infinite`}handleAnimationEnd(){this.hasFiniteAnimation()&&(this.running=!1,this.syncAnimationPlayState())}restartAnimation(){this.track.style.animationName=`none`,this.track.offsetWidth,this.track.style.removeProperty(`animation-name`)}hasFiniteAnimation(){return this.behavior===`slide`&&!this.hasAttribute(a)?!0:this.hasAttribute(a)&&Number.isFinite(this.loop)&&this.loop>0}};typeof customElements>`u`||(customElements.get(`re-marquee`)||customElements.define(`re-marquee`,O),customElements.get(`re-marquee-ble`)||customElements.define(`re-marquee-ble`,O));